// ----------------------------------------------------------------------

/* Imports */

/* Relative Imports */
import axiosInstance from 'config/axiosConfig';

// ----------------------------------------------------------------------
export const insertEmployeeAddressDetailRequest = (
  reqData: FormData
): Promise<any> => {
  return axiosInstance
    .post('admin/company/employeeAddress/InsertEmployeeAddress', reqData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    .then((response) => response.data);
};

export const updateEmployeeAddressDetailRequest = (
  reqData: FormData
): Promise<any> => {
  return axiosInstance
    .put('admin/company/employeeAddress/UpdateEmployeeAddress', reqData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    .then((response) => response.data);
};
