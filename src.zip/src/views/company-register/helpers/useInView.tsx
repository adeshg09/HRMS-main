import { useRef } from 'react';
import { useInView as useInViewFromFramer } from 'framer-motion';

export default ({ once = true, margin = '-30px 0px 0px 0px' } = {}): any => {
  const ref = useRef(null);
  const isInView = useInViewFromFramer(ref, {
    once
  });

  return [ref, isInView];
};
