export { default as UploadSingleImage } from './UploadSingleImage';
